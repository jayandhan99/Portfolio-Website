# Portfolio-Website

## Table of contents
* [General info](#general-info)
* [Technologies](#technologies)
* [Setup](#setup)

## General info
This is a portfolio website that contains my personal information, my projects, my skills, and my contact information. It is a website that is built using HTML, CSS, and JavaScript. It is a responsive website that can be viewed on different devices such as mobile phones, tablets, and desktops.

## Technologies
Project is created with:
* HTML
* CSS
* JavaScript

## View the website
To view the website, click on the link below:

https://krish-depani.vercel.app/

## If you like this project, please give it a 🌟.
## Thank you 😊.
